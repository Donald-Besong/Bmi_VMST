import iterdata
import dataanalysis

import argparse

#******************begin defining arguments
parser = argparse.ArgumentParser(description="testing...")
parser.add_argument('--xparam', help='this is just a test', default=10)
parser.add_argument('--json_source', help='data source', default='data.json')
parser.add_argument('--nmin', help='starting row', default=0)
parser.add_argument('--nmax', help='ending row')
parser.add_argument('--category', help='category/health risk level', default='normal_weight')
parser.add_argument('--full_message', help='print dataframe', default=0)
#******************end defining arguments

#*****************begin reading arguments
my_args = parser.parse_args()
data_source = my_args.json_source
nMin = int(my_args.nmin)
nMax = int(my_args.nmax)
category = my_args.category
fullMessage = int(my_args.full_message)
#*****************end reading arguments

x = iterdata.IterData(data_source)
x.iterRead()

A = dataanalysis.DataAnalysis(x.jsonProperty)
A.createDf(nMin,nMax)
A.calcBmi()

#below if to help with filtering
x_low = [0, 18.5, 25, 30, 35, 40]
x_high = [18.5, 25, 30, 35, 40, 10000]
x_cat = ["under_weight", "normal_weight", "over_weight", "moderately_obese", "severely obese", "very_severely_obese"]
x_risk = ["malnutrition risk", "low risk", "enhanced risk", "medium risk", "high risk", "very high risk"]

categoryTable = {cat: {"high":high, "low":low, "risk":risk} for cat, high, low, risk in zip(x_cat, x_high, x_low, x_risk)}

B = A.pandasDf.loc[A.pandasDf.Bmi.between(categoryTable[category]['low'], categoryTable[category]['high'])]
message = categoryTable[category]['risk']
if fullMessage > 0:
 print('The following have %s' % message)
 print(B)
print('***Number of people with %s is %s ***' % (message, len(B)))





